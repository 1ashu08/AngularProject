var app=angular.module('angularApp',[])
                .controller('angularAppController',function($scope,$http){
                    $scope.Data=[
                        {companyName:'Wipro',companyEmployee:'10700',companyHeadOffice:'Bangalore',visible:true},
                        {companyName:'Infosys',companyEmployee:'10900',companyHeadOffice:'Mumbai',visible:true},
                        {companyName:'TCS',companyEmployee:'258700',companyHeadOffice:'Kolkata',visible:true},
                        {companyName:'Congnizant Technology',companyEmployee:'19800',companyHeadOffice:'Mumbai',visible:true},
                        {companyName:'Accenture',companyEmployee:'356400',companyHeadOffice:'Kolkata',visible:true}
                    ];
                    $scope.dataFilter="";
                    $scope.newData={companyName:'',companyEmployee:'',companyHeadOffice:'',visible:true};
                    $scope.addCompany=function()
                    {
                        var ret=validate($scope.newData.companyName);
                        if(ret==true)
                        {
                            $scope.Data.push($scope.newData);
                            $scope.newData={companyName:'',companyEmployee:'',companyHeadOffice:'',visible:true};
                            window.alert("Company Data Added");
                        }
                        else
                        {
                            window.alert("Company Already Exist");
                        }
                    }
                    function validate(name)
                    {
                        for(var i=0;i<$scope.Data.length;i++)
                        {
                            if($scope.Data[i].companyName.toLowerCase()==name.toLowerCase())
                            {
                                return false;
                            }
                            
                        }   
                        return true; 
                    }
                    $scope.delete=function(index)
                    {
                        $scope.Data.splice(index, 1);
                        //this.data.remove=true;
                        window.alert("Company Removed From List");
                    }
                    $scope.filterFunction=function()
                    {
                        if($scope.dataFilter=="")
                        {

                            for(var i=0;i<$scope.Data.length;i++)
                            {
                                $scope.Data[i].visible=true;   
                            }    
                        }
                        else
                        {
                            for(var i=0;i<$scope.Data.length;i++)
                            {
                                data=$scope.Data[i];
                                //console.log($scope.dataFilter);
                                if(data.companyName.toLowerCase().includes($scope.dataFilter.toLowerCase()))
                                {
                                    data.visible=true;
                                }
                                else
                                {
                                    data.visible=false;
                                }
                            }
                        }
                        
                        /*for(var i=0;i<$scope.Data.length;i++)
                            {
                                console.log($scope.Data[i]);
                            }
                        */    
                    }
                });